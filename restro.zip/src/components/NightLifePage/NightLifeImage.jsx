// import React from 'react'


const NightLifeImage = () => {
  return (
    <div>
      
    </div>
  )
}

export default NightLifeImage;
