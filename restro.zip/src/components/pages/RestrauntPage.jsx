import { Box } from '@mui/material';
import Restruant from '../components/Restraunt/Restruant'

const RestrauntPage = () => {
  return (
    <Box width={'auto'} height={'full'}>
      <Restruant />
      

    </Box>
  );
}

export default RestrauntPage
